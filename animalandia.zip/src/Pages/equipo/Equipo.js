import Navbar from "../../Components/navbar/Navbar";
import Header from "../../Components/header/Header";
import Footer from "../../Components/footer/Footer";

function Equipo() {
  return (
    
    <div>
    <Header />
    <Navbar />
    <h1>Equipo</h1>
    <Footer />
    </div>
  );
}

export default Equipo;