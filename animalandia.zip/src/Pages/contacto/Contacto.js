import Header from "../../Components/header/Header";
import Navbar from "../../Components/navbar/Navbar";
import Footer from "../../Components/footer/Footer";

function Contacto() {
    return (
      <div>
      <Header />
      <Navbar />
      <Footer />
      </div>
    );
  }
  
  export default Contacto;