import Footer from '../../Components/footer/Footer';
import Header from '../../Components/header/Header';
import Navbar from '../../Components/navbar/Navbar';


import './Home.css';

function Home() {
  return (
    <div>
    <Header />
    <Navbar />
    <Footer />
    </div>
  );
}

export default Home;