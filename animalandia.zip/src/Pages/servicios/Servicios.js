import Header from "../../Components/header/Header";
import Navbar from "../../Components/navbar/Navbar";
import Footer from "../../Components/footer/Footer";
import Sectserv from "../../Components/servicios/Sectserv";

function Servicios() {
    return (
      <div>
      <Header />
      <Navbar />
      <Sectserv />
      <Footer />
      </div>
    );
  }
  
  export default Servicios;