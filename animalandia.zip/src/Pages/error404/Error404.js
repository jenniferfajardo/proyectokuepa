
function Error404() {
    return (
      <div></div>
    );
  }
  
  export default Error404;