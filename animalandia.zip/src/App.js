import './App.css';
import Equipo from './Pages/equipo/Equipo';

function App() {
  return (
    <div className="container-fluid overflow-hidden">
      
    </div>
  );
}

export default App;
